# BankdataApiApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**handleBankdataValidationResults**](BankdataApiApi.md#handleBankdataValidationResults) | **POST** /api/customer/bankdata/validationresults | Endpoint to handle bankdata validation results (ADIV). Matches BPM818


<a name="handleBankdataValidationResults"></a>
# **handleBankdataValidationResults**
> handleBankdataValidationResults(uuid)

Endpoint to handle bankdata validation results (ADIV). Matches BPM818

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.BankdataApiApi;


BankdataApiApi apiInstance = new BankdataApiApi();
Object uuid = null; // Object | 
try {
    apiInstance.handleBankdataValidationResults(uuid);
} catch (ApiException e) {
    System.err.println("Exception when calling BankdataApiApi#handleBankdataValidationResults");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**Object**](.md)|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

