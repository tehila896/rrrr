# ChargebackApiApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateChargebacks**](ChargebackApiApi.md#updateChargebacks) | **POST** /api/customer/chargeback | Update chargebacks. Matches BPM304


<a name="updateChargebacks"></a>
# **updateChargebacks**
> updateChargebacks(uuid)

Update chargebacks. Matches BPM304

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ChargebackApiApi;


ChargebackApiApi apiInstance = new ChargebackApiApi();
Object uuid = null; // Object | 
try {
    apiInstance.updateChargebacks(uuid);
} catch (ApiException e) {
    System.err.println("Exception when calling ChargebackApiApi#updateChargebacks");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**Object**](.md)|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

