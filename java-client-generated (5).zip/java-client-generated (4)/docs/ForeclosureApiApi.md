# ForeclosureApiApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateForeclosure**](ForeclosureApiApi.md#updateForeclosure) | **POST** /api/customer/foreclosure | Endpoint to handle foreclosure requests. Matches BPM206


<a name="updateForeclosure"></a>
# **updateForeclosure**
> updateForeclosure(uuid)

Endpoint to handle foreclosure requests. Matches BPM206

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ForeclosureApiApi;


ForeclosureApiApi apiInstance = new ForeclosureApiApi();
Object uuid = null; // Object | 
try {
    apiInstance.updateForeclosure(uuid);
} catch (ApiException e) {
    System.err.println("Exception when calling ForeclosureApiApi#updateForeclosure");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**Object**](.md)|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

